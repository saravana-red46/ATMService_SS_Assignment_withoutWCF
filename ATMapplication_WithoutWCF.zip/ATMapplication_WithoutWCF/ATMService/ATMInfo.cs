﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ATMService
{
   
        
      public  class ATMInfo
        {
            
            public Int64 CardNumber;

            
            public string CustomerName;

            
            public Double Amount;

        }
    
}
