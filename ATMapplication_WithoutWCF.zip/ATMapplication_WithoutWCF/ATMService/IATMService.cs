﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.Threading.Tasks;

namespace ATMService
{
    
  public interface IATMService
    {
        
        double CheckBalance(Int64 CardNumber);

        
        bool DepositAmount(ATMInfo atmInfo);

        
        bool WithDrawAmount(ATMInfo atmInfo);
                
    }
}
