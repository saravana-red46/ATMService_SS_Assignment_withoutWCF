﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ATMService
{
    
   public class ATMService : IATMService
    {

        public bool DepositAmount(ATMInfo atmInfo)
        {
            var list = AtmList;
            AtmList.Where(p => p.CardNumber == atmInfo.CardNumber).Update(p => p.Amount = p.Amount + atmInfo.Amount);
            SaveData(atmInfo);
            return true;
        }

        public static List<ATMInfo> AtmList = GetAllCardDetails();
        public static List<ATMInfo> GetAllCardDetails()
        {
            XDocument xdoc = XDocument.Load("P:\\ATMTransaction.xml");
           
            List<ATMInfo> atmInfoList = (from xml in xdoc.Elements("ATMTransaction").Elements("card")
                                     select new ATMInfo
                                     {
                                         CardNumber = Convert.ToInt64(xml.Attribute("Number").Value),
                                         CustomerName = xml.Element("Customername").Value,
                                         Amount = Convert.ToDouble(xml.Element("Amount").Value)
                                     }).ToList();
            return atmInfoList;
        }

        public double CheckBalance(Int64 cardNumber)
        {
            double balanceAmount = 0;
            var item = AtmList.First(x => x.CardNumber == cardNumber);
            balanceAmount = Convert.ToDouble(item.Amount.ToString());
            return balanceAmount;
        }

        public bool WithDrawAmount(ATMInfo atmInfo)
        {
            var list = AtmList;
            AtmList.Where(p => p.CardNumber == atmInfo.CardNumber).Update(p => p.Amount = p.Amount-atmInfo.Amount);
            SaveData(atmInfo);
            return true;
        }

        private void SaveData(ATMInfo atmInfo)
        {


            XDocument xdoc = XDocument.Load("P:\\ATMTransaction.xml");
            var xquery = from transact in xdoc.Elements("ATMTransaction").Elements("card")
                        where Convert.ToInt64(transact.Attribute("Number").Value) == atmInfo.CardNumber
                        select transact;

            foreach (XElement itemElement in xquery)
            {
                itemElement.SetElementValue("Amount", atmInfo.Amount.ToString());
            }

            xdoc.Save("P:\\ATMTransaction.xml");
            
        }
    }  
 

public static class LinqUpdates
{
    public static void Update<T>(this IEnumerable<T> source, Action<T> action)
    {
        foreach (var item in source)
            action(item);
    }
}

}


