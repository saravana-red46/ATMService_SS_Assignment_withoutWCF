﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;

namespace ATMapplication_WithoutWCF
{
  public class Logger : ILogger
    {
        public void WriteLog(string message)
        {

            try
            {
               StreamWriter streamWrite = new StreamWriter(Directory.GetCurrentDirectory()+ @"\\CardActivityLog.xml", true);
                XElement xmlEntry = new XElement("logEntry",
                     new XElement("Activity", message),
                    new XElement("ActivityHappenedAt", System.DateTime.Now.ToString())
                   );
                streamWrite.WriteLine(xmlEntry);
                streamWrite.Close();
            }
            catch (Exception ex)
            {
            }
        }

        public void WriteLog(Exception exception)
        {

            try
            {

                StreamWriter streamWrite = new StreamWriter(Directory.GetCurrentDirectory() + @"\\ErrorLog.xml", true);
                XElement xmlEntry = new XElement("ErrorLogEntry",                    
                    new XElement("Exception",
                        new XElement("Source", exception.Source),
                        new XElement("Message", exception.Message),
                        new XElement("Stack", exception.StackTrace)
                     ),
                    new XElement("ExecpetionOccuredAt", System.DateTime.Now.ToString())
                );

                if (exception.InnerException != null)
                {
                    xmlEntry.Element("Exception").Add(
                        new XElement("InnerException",
                            new XElement("Source", exception.InnerException.Source),
                            new XElement("Message", exception.InnerException.Message),
                            new XElement("Stack", exception.InnerException.StackTrace))
                        );
                }
                streamWrite.WriteLine(xmlEntry);
                streamWrite.Close();
            }
            catch (Exception ex)
            {
            }
        }
    }
}
