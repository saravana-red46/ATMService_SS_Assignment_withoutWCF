﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMapplication_WithoutWCF
{
    interface ILogger
    {
        void WriteLog(String message);

        void WriteLog(Exception ex);
    }
}
