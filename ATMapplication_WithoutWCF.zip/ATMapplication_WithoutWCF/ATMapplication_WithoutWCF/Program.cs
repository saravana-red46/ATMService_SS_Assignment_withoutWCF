﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ATMService;

namespace ATMapplication_WithoutWCF
{
    class Program
    {
        public static object ConfigurationManager { get; private set; }

        static void Main(string[] args)
        {
            Logger log = new Logger();
            try
            {


                string cardNumber = "";
                Int64 iCardNumber;
                string pin = "";
                int iPin;
                string action = "";
                int iAction;

                bool validCardNumber;
                bool validPin;
                bool validAction;


                Console.WriteLine("Welcome to ATM App");
                Console.WriteLine("------------------");
                Console.WriteLine("To Access this ATM please enter your 16 digit number :");
                Card:
                cardNumber = Console.ReadLine();
                validCardNumber = Int64.TryParse(cardNumber, out iCardNumber);
                if (!((cardNumber.Length == 16) && (validCardNumber == true) && (verifyCardNumber(iCardNumber))))
                {
                    Console.WriteLine("Invalid CardNumber.");
                    log.WriteLog("Invlaid CardNumber Entered: " + cardNumber);
                    Console.WriteLine("Please enter your valid 16 digit number:");
                    goto Card;
                }
                else
                {
                    Console.WriteLine("Please enter the 4 digit PIN :");
                    pin = Console.ReadLine();
                }
                validPin = int.TryParse(pin, out iPin);

                if (!((pin.Length == 4) && (validPin == true) && (iPin == 1234)))
                {
                    Console.WriteLine("Invalid Pin number.");
                    log.WriteLog("Invlaid Pin number Entered for Card: " + cardNumber);
                    Console.WriteLine("To avoid Unauthorized access, Press any key to exit");
                    Console.Read();
                    Environment.Exit(0);
                }

                //Console.WriteLine("Your CardNumber & Pin is : {0}, {1}", iCardNumber, iPin);
                // Console.Read();
                // Validate card number with PIN

                Console.WriteLine("Your Card has authorized");
                RedoAction:
                Console.WriteLine("Please Use the below services by pressing the relevant number");
                Console.WriteLine("1. Check Balance ");
                Console.WriteLine("2. Deposit Amount");
                Console.WriteLine("3. Withdraw Amount ");
                Console.WriteLine("4. LogOut ");

                Action:
                action = Console.ReadLine();
                validAction = int.TryParse(action, out iAction);

                if (!((action.Length == 1) && (validAction == true)))
                {
                    Console.WriteLine("Invalid Action.");
                    log.WriteLog("Invlaid Action entered for the card: " + cardNumber);
                    Console.WriteLine("Please re enter the action");
                    goto Action;
                }
                doAction(iAction, iCardNumber);
                Console.WriteLine("Want to continue Press Y if want to exit press any key");
                if (Console.ReadLine() == "Y")
                {
                    goto RedoAction;
                }
                else
                {
                    log.WriteLog("Card holder exits from the system : " + cardNumber);
                    doExit();
                }
                Console.Read();
            }
            catch (Exception ex)
            {
                log.WriteLog(ex);
            }
        }

        private static void doAction(int actionId, Int64 cardNumber)
        {

            string sAmount = "";
            double amount = 0;
            double balance = 0;
            bool transactionStatus;
            // ATMService.ATMServiceClient proxyClient = new ATMServiceClient();
             ATMService.ATMInfo atmInfo;
            ATMService.ATMService serv = new ATMService.ATMService();
            switch (actionId)
            {
                case 1:

                    displayBalance(serv, cardNumber);
                    break;

                case 2:
                    Console.WriteLine("Please enter the deposit amount (multiples of 100) :");
                    sAmount = Console.ReadLine();
                    amount = Double.Parse(sAmount);
                    if (CommonValidation.checkAmountMultiples(amount) == false)
                    {
                        Console.WriteLine("You have entered Invalid amount.");
                        return;
                    }
                    atmInfo =
                                       new ATMService.ATMInfo()
                                       {
                                           CardNumber = cardNumber,
                                           Amount = amount
                                       };
                    transactionStatus = serv.DepositAmount(atmInfo);
                    if (transactionStatus)
                    {
                        Console.WriteLine("You deposited the amount {0} successfuly", sAmount);

                        displayBalance(serv, cardNumber);
                    }
                    else
                    {
                        Console.WriteLine("Your amount deposit action failed,Contact bank.");
                    }

                    break;

                case 3:
                    Console.WriteLine("Please enter the withdrawl amount (multiples of 100) :");
                    sAmount = Console.ReadLine();
                    amount = Double.Parse(sAmount);
                    if (CommonValidation.checkAmountMultiples(amount) == false)
                    {
                        Console.WriteLine("You have entered Invalid amount.");
                        return;
                    }

                    balance = serv.CheckBalance(cardNumber);
                    if (balance < amount)
                    {
                        Console.WriteLine("You have insufficient balance.");
                        return;
                    }
                    atmInfo =
                                     new ATMService.ATMInfo()
                                     {
                                         CardNumber = cardNumber,
                                         Amount = amount
                                     };

                    transactionStatus = serv.WithDrawAmount(atmInfo);
                    if (transactionStatus)
                    {
                        Console.WriteLine("You withdrawn the amount {0} successfuly", sAmount);
                        displayBalance(serv, cardNumber);
                    }
                    else
                    {
                        Console.WriteLine("Your amount deposit action failed,Contact bank.");
                    }

                    break;

                case 4:
                    doExit();
                    break;

                default:
                    break;
            }
        }

        private static void displayBalance(ATMService.ATMService serv, Int64 cardNumber)
        {
            double balance = 0;
            balance = serv.CheckBalance(cardNumber);
            Console.WriteLine("Your Card balance as on today  {0}, : {1}", DateTime.Now.ToString(), balance.ToString());
        }

        private static void doExit()
        {
            Console.WriteLine("You are logged out from the System");
            Console.Read();
            Environment.Exit(0);
        }

        private static bool verifyCardNumber(Int64 cardNumber)
        {


            var appSettings = System.Configuration.ConfigurationManager.AppSettings;
            string result = appSettings["CardNumbers"];
            List<Int64> cardNumbers = result.Split(',').Select(Int64.Parse).ToList();

            return cardNumbers.Contains(cardNumber);
        }


    }
}
