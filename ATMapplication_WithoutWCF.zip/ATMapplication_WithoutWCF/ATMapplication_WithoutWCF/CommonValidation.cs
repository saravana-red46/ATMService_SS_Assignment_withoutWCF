﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMapplication_WithoutWCF
{
   public static class CommonValidation
    {
        const int multiples = 100;
            //Extension method to validate multiples of 100
            public static bool checkAmountMultiples(this Double Amount)
            {
                    return Amount % multiples == 0 ? true : false;

            }
       
    }
}
